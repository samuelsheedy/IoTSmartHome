__version__ = "1.4.0.dev0"


class MQTTException(Exception):
    pass
